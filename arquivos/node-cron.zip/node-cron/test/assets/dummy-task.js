exports.task = () => {
    return 'dummy task';
};